//
//  AppDelegate.h
//  NHGiftAnimationExample
//
//  Created by NegHao.W on 16/7/10.
//  Copyright © 2016年 NegHao.W. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

