//
//  PHPayChannelProtocol.h
//  PPDemo
//
//  Created by 安武 on 2017/5/21.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PHPayChannelProtocol <NSObject>

@end
