//
//  PHPay.h
//  PHPay
//
//  Created by 安武 on 2017/5/29.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PHPay.
FOUNDATION_EXPORT double PHPayVersionNumber;

//! Project version string for PHPay.
FOUNDATION_EXPORT const unsigned char PHPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PHPay/PublicHeader.h>
#import "PHPayEngine.h"

