//
//  PHPayMacro.h
//  PPDemo
//
//  Created by 安武 on 2017/5/29.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#ifndef PHPayMacro_h
#define PHPayMacro_h

#import "PHPayError.h"


typedef void(^PHPayComplation)(id response, PHPayError *error);

#define PAY_WXPAY @"wxpay"
#define PAY_UNIONPAY @"unionpay"
#define PAY_ALIPAY @"alipay"
#define PAY_APPLE @"applepay"
#define PAY_IAP @"iappay"

#endif /* PHPayMacro_h */
