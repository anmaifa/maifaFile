//
//  ChildVCFive.m
//  SGPageViewExample
//
//  Created by apple on 17/4/19.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import "ChildVCFive.h"

@interface ChildVCFive ()

@end

@implementation ChildVCFive

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor brownColor];
}


@end
