//
//  ChildVCSeven.m
//  SGPageViewExample
//
//  Created by apple on 17/4/19.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import "ChildVCSeven.h"

@interface ChildVCSeven ()

@end

@implementation ChildVCSeven

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor blueColor];
}


@end
