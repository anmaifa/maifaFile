//
//  NavigationBarVC.h
//  SGPageViewExample
//
//  Created by apple on 17/4/13.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationBarVC : UIViewController

@end
