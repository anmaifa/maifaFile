//
//  JQHeaderView.h
//  JQScrollViewDemo
//
//  Created by jianquan on 2016/11/10.
//  Copyright © 2016年 JoySeeDog. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface JQHeaderView : UIView

@property (nonatomic, weak) UITableView *tableView;

@property(nonatomic,copy)NSMutableArray *tableViews;

@end
