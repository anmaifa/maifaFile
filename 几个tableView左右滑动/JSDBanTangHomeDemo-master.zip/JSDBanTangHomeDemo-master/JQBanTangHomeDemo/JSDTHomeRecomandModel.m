//
//  JQBTHomeRecomandModel.m
//  JQBanTangHomeDemo
//
//  Created by jianquan on 2016/11/23.
//  Copyright © 2016年 JoySeeDog. All rights reserved.
//

#import "JSDTHomeRecomandModel.h"

@implementation JSDTHomeRecomandModel

@end
