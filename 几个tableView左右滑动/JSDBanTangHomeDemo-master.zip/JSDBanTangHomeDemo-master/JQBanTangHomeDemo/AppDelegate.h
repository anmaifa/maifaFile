//
//  AppDelegate.h
//  JQBanTangHomeDemo
//
//  Created by jianquan on 2016/11/18.
//  Copyright © 2016年 JoySeeDog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

