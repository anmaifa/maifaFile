//
//  JQBTHomeTableViewCell.h
//  JQBanTangHomeDemo
//
//  Created by jianquan on 2016/11/23.
//  Copyright © 2016年 JoySeeDog. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JQBTHomeRecomandModel;

@interface JQBTHomeTableViewCell : UITableViewCell

@property (nonatomic, strong) JQBTHomeRecomandModel *homeRecomandModel;

@end
