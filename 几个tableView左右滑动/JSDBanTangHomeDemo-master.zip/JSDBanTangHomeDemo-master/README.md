# JSDBanTangHomeDemo

![License MIT](https://img.shields.io/badge/license-MIT-green.svg?style=flat)&nbsp; [![China 中文文档](https://img.shields.io/badge/China-%E4%B8%AD%E6%96%87%E6%96%87%E6%A1%A3-blue.svg)](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/CN.md9)&nbsp;
 ![build passing](https://img.shields.io/badge/build-passing-brightgreen.svg)
 
by [Joyseedog](http://www.iseedog.com) 
## DESCRIPTION ##

[![Screenshot](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome01.gif)](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome01.gif)

[![Screenshot](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome02.gif)](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome02.gif)


[![Screenshot](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome03.gif)](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome03.gif)


[![Screenshot](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome04.gif)](https://github.com/JoySeeDog/JSDBanTangHomeDemo/blob/master/gif/bantanghome04.gif)


 * This demo Provides a good idea to achieve a app likes BanTang
 * build in xcode8 with ARC.


##LICENSE
Distributed under the MIT License.

##Contributions
Any contribution is more than welcome! You can contribute through pull requests and issues on GitHub.

#Author

Contact me on my email: joyseedog@gmail.com

