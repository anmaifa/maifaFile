//
//  PHButton.h
//  App
//
//  Created by 安武 on 2017/6/4.
//  Copyright © 2017年 安武. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Masonry.h>
#import "PHMacro.h"

@class PHButton;

typedef void(^PHButtonClick)(PHButton *sender);

@interface PHButton : UIButton

/**
 创建
 */
+ (PHButton *(^)(BOOL enable))ph_create;

/**
 设置背景色
 */
- (PHButton *(^)(UIColor *bgColor))ph_backgroundColor;
/**
 圆角率
 */
- (PHButton *(^)(NSInteger radius))ph_radius;

/**
 添加到View 中  并且添加了布局
 */
- (PHButton *(^)(id view, PHLayout layout))ph_addToView;


/**
 设置标题
 */
- (PHButton *(^)(NSString *title))ph_title;

/**
 设置图片 imageName 或者 图片路径  或者image 都可以
 */
- (PHButton *(^)(id image))ph_image;

/**
 设置字体颜色
 */
- (PHButton *(^)(UIColor *textColor))ph_textColor;

/**
 单击事件
 */
- (PHButton *(^)(PHButtonClick clickBlock))ph_clickAction;



@end
