//
//  AppDelegate+AppService.m
//  App
//
//  Created by 安武 on 2017/6/16.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "AppDelegate+AppService.h"
//#import <DCURLRouter/DCURLRouter.h>
#import "PHLocationHelper.h"
#import "PHNetworkHelper.h"
#import "PHLogHelper.h"

@implementation AppDelegate (AppService)

- (void)initService {
//    [DCURLRouter loadConfigDictFromPlist:@"DCURLRouter.plist"];
    [PHLocationHelper ph_locationManager];//初始化定位服务
    [PHNetworkHelper ph_monitorNetworkStatus];//初始化网络状态的服务
    [PHLogHelper ph_startLogManager];//初始化日志服务
}

@end
