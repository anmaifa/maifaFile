//
//  UIGestureRecognizer+PHUtils.h
//  App
//
//  Created by 安武 on 2017/6/23.
//  Copyright © 2017年 安武. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIGestureRecognizer (PHUtils)

@end
