//
//  PHBaseVC+Protocol.h
//  App
//
//  Created by Alex on 2017/6/20.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHBaseVC.h"

@interface PHBaseVC (Protocol)

@end
