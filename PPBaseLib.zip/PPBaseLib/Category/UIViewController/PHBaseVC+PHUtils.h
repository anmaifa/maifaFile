//
//  PHBaseVC+PHUtils.h
//  App
//
//  Created by Alex on 2017/6/19.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHBaseVC.h"

@interface PHBaseVC (PHUtils)

@end
