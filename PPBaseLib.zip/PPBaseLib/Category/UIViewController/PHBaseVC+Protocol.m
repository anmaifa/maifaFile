//
//  PHBaseVC+Protocol.m
//  App
//
//  Created by Alex on 2017/6/20.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHBaseVC+Protocol.h"

@implementation PHBaseVC (Protocol)

@end
