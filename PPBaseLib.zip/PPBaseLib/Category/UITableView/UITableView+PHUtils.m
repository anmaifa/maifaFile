//
//  UITableView+PHUtils.m
//  App
//
//  Created by 安武 on 2017/6/25.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "UITableView+PHUtils.h"
#import "PHMacro.h"
#import "PHTools.h"

@implementation UITableView (PHUtils)

+ (void)load {
}

@end
