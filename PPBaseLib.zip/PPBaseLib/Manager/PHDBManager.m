//
//  DBManager.m
//  App
//
//  Created by 安武 on 2017/6/17.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHDBManager.h"
#import "PHMacro.h"
#import <sqlite3.h>

@implementation PHDBManager

PH_DefaultManager(PHDBManager);

- (NSString *)dbPath {
    if (!_dbPath) {
        _dbPath = [PH_DOCUMENT_PATH stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.db", PH_BundleIdentifier]];
    }
    return _dbPath;
}

- (FMDatabaseQueue *)databaseQueue {
    if (!_databaseQueue) {
        _databaseQueue = [FMDatabaseQueue databaseQueueWithPath:[PHDBManager defaultManager].dbPath];
    }
    return _databaseQueue;
}



@end
