//
//  PHBaseVC.h
//  Example
//
//  Created by 安武 on 2017/5/10.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PHMacro.h"
#import "PHTools.h"
#import <AFNetworking.h>
#import "PHBaseVCProtocol.h"
#import "PHNetworkProtocol.h"
#import "PHLocationProtocol.h"
#import "PHLogProtocol.h"
//#import <DCURLRouter.h>


@interface PHBaseVC : UIViewController<PHBaseVCProtocol, PHNetworkProtocol, PHLocationProtocol, PHLogProtocol>

/**
 上个页面传下的参数
 */
@property (nonatomic, strong) id lastPageData;

/**
 页面返回时的回调
 */
@property (nonatomic, copy) PHVCBackBlock backBlock;

@end
