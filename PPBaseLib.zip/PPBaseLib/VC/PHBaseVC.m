//
//  PHBaseVC.m
//  Example
//
//  Created by 安武 on 2017/5/10.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHBaseVC.h"
#import "PHMacro.h"
//#import <ReactiveObjC/RACEXTScope.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import "PHView.h"

@interface PHBaseVC () {
}

@end

@implementation PHBaseVC

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    PHBaseVC *baseVC = [super allocWithZone:zone];
    @weakify(baseVC);
    [[baseVC rac_signalForSelector:@selector(viewDidLoad)] subscribeNext:^(id x) {
        @strongify(baseVC);
        if ([baseVC respondsToSelector:@selector(ph_addSubviews)]) {
            [baseVC ph_addSubviews];
        }
        if ([baseVC respondsToSelector:@selector(ph_bindModel)]) {
            [baseVC ph_bindModel];
        }
        if ([baseVC respondsToSelector:@selector(ph_request)]) {
            [baseVC ph_request];
        }
    }];
    [[baseVC rac_signalForSelector:@selector(viewWillAppear:)] subscribeNext:^(id x) {
        @strongify(baseVC);
        if ([baseVC respondsToSelector:@selector(ph_loadData)]) {
            [baseVC ph_loadData];
        }
    }];
    
    [[baseVC rac_signalForSelector:@selector(viewDidAppear:)] subscribeNext:^(id x) {
        @strongify(baseVC);
        if ([baseVC respondsToSelector:@selector(ph_autolayout)]) {
            [baseVC ph_autolayout];
        }
    }];
    
    [[baseVC rac_signalForSelector:@selector(viewDidDisappear:)] subscribeNext:^(id x) {
        @strongify(baseVC);
        if ([baseVC respondsToSelector:@selector(ph_dismiss)]) {
            [baseVC ph_dismiss];
        }
        //递归所有的view 通知当前vc生命周期结束
        [baseVC _recursionSubviews:baseVC.view];
    }];
    
    return baseVC;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] postNotificationName:PH_VIEWAPPEAR object:self];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] postNotificationName:PH_VIEWDISAPPEAR object:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -- private
- (void)_recursionSubviews:(UIView *)targetView {
    for (PHView *subview in targetView.subviews) {
        if (subview && [subview respondsToSelector:@selector(ph_dismiss)]) {
            [subview ph_dismiss];
        }
        [self _recursionSubviews:subview];
    }
}

#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    PHBaseVC *vc = segue.destinationViewController;
    @weakify(self);
    if ([vc respondsToSelector:@selector(ph_nextData:backBlock:)]) {
        [vc ph_nextData:sender backBlock:^(id data) {
            @strongify(self);
            [self ph_back:data];
        }];
    }
}

#pragma mark RAC


- (void)ph_nextData:(id)data
          backBlock:(PHVCBackBlock)backBlock {
    self.lastPageData = data;
    self.backBlock = backBlock;
}

@end
