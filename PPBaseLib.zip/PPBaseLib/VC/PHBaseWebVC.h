//
//  PHBaseWebVC.h
//  App
//
//  Created by 安武 on 2017/6/14.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHBaseVC.h"

@interface PHBaseWebVC : PHBaseVC

@end
