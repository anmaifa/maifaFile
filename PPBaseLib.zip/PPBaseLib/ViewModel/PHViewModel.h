//
//  PHViewModel.h
//  App
//
//  Created by 安武 on 2017/6/17.
//  Copyright © 2017年 安武. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PHViewModel : NSObject

@end
