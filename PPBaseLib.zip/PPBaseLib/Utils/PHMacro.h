//
//  PHMacro.h
//  Example
//
//  Created by 安武 on 2017/5/10.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#ifndef PHMacro_h
#define PHMacro_h

#import "PHBlockMarco.h"        //Block 定义
#import "PHSystemMarco.h"       //系统的宏定义
#import "PHServiceMarco.h"      //服务的宏定义
#import "PHColorMarco.h"        //颜色的宏定义
#import "PHFontMarco.h"         //字体的宏定义
#import "PHURLMarco.h"          //URL的宏定义
#import "PHKeyMarco.h"          //三方key的宏定义
#import "PHNotificationMarco.h" //通知宏定义

#endif /* PHMacro_h */
