//
//  PHBlockMarco.h
//  App
//
//  Created by 安武 on 2017/6/16.
//  Copyright © 2017年 安武. All rights reserved.
//

#ifndef PHBlockMarco_h
#define PHBlockMarco_h
#import <UIKit/UIKit.h>
#import <Masonry.h>


/**
 VC dismiss 的Block

 @param response 响应
 */
typedef void(^PHDismissBlock)(id response);
/**
 DB 操作的回调

 @param success 是否成功
 @param response 回调的数据
 */
typedef void(^PHDBManagerResultBlock)(BOOL success, id response);


/**
 vc 回调的Block
 
 @param response 回调参数
 */
typedef void(^PHVCBackBlock)(id response);

/**
 view 回调Block
 
 @param response 回调参数
 */
typedef void(^PHViewBlock)(id response);

/**
 cell 回调Block
 
 @param indexPath indexpath
 @param response 数据
 */
typedef void(^PHCellBlock)(NSIndexPath *indexPath, id response);

/**
 Cell上面添加事件的回调
 
 @param indexPath indexPath
 @param response 回调参数
 */
typedef void(^PHCellActionBlock)(NSIndexPath *indexPath,  id response);

/**
 搜索框的搜索回调
 
 @param searchBar 搜索框
 */
typedef void(^PHSearchBlock)(UISearchBar *searchBar);

typedef void(^PHLayout)(MASConstraintMaker *make);

#endif /* PHBlockMarco_h */
