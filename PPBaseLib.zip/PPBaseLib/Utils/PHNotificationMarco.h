//
//  PHNotificationMarco.h
//  App
//
//  Created by 安武 on 2017/6/16.
//  Copyright © 2017年 安武. All rights reserved.
//

#ifndef PHNotificationMarco_h
#define PHNotificationMarco_h

#define PH_VIEWAPPEAR @"PH_VIEWAPPEAR"
#define PH_VIEWDISAPPEAR @"PH_VIEWDISAPPEAR"



#endif /* PHNotificationMarco_h */
