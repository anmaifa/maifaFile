//
//  PHModel.m
//  Example
//
//  Created by 安武 on 2017/5/10.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHModel.h"
#import <objc/message.h>
#import "NSDictionary+Safe.h"

@interface PHModel () {
}

@end

@implementation PHModel

#pragma mark -- 
/**
 获取当前的ORM映射
 
 @return 映射字典
 */
+ (NSDictionary *)ph_keyMapper {
    return @{};
}

#pragma mark -- MJ method
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return [[self class] ph_keyMapper];
}

#pragma mark -- NSCopying delegate

- (instancetype)copyWithZone:(NSZone *)zone {
    return [[self class] mj_objectWithKeyValues:self.mj_keyValues];
}

@end
