//
//  PHModel.h
//  Example
//
//  Created by 安武 on 2017/5/10.
//  Tel:(+86)13682465601  Mail:ananwu@126.com
//  Copyright © 2017年 安武. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MJExtension/MJExtension.h>

@interface PHModel : NSObject<NSCopying>

/**
 获取当前的ORM映射
 
 @return 映射字典
 */
+ (NSDictionary *)ph_keyMapper;

@end
