//
//  PHLocationHelper.m
//  App
//
//  Created by 安武 on 2017/6/18.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHLocationHelper.h"
#import "PHBaseVC.h"
#import "NSMutableString+PHUtils.h"

@interface PHLocationHelper() {
}

#pragma mark -- 定位相关
@property (nonatomic, strong) CLLocationManager *locationManager;

/**
 地址反向解析协议
 */
@property (nonatomic, strong) CLGeocoder *geocoder;
/**
 地址信息
 */
@property (nonatomic, strong) NSMutableString *address;

/**
 保持一直定位
 */
@property (nonatomic, assign) BOOL keepLocation;//

@end


@implementation PHLocationHelper

PH_DefaultManager(PHLocationHelper);

- (CLLocationManager *)locationManager {
    if (!_locationManager) {
        _locationManager = [[CLLocationManager alloc] init];
        _locationManager.delegate = self;
        _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        _locationManager.distanceFilter = 100;
    }
    return _locationManager;
}

- (CLGeocoder *)geocoder {
    if (!_geocoder) {
        _geocoder = [[CLGeocoder alloc] init];
    }
    return _geocoder;
}

- (NSMutableString *)address {
    if (!_address) {
        _address = [[NSMutableString alloc] init];
    }
    return _address;
}

/**
 初始化定位设置
 */
+ (void)ph_locationManager {
    if ([CLLocationManager locationServicesEnabled]) {
        [[PHLocationHelper defaultManager].locationManager requestWhenInUseAuthorization];
        [[PHLocationHelper defaultManager].locationManager requestAlwaysAuthorization];
//        self.locationManager.allowsBackgroundLocationUpdates = YES;
        [PHLocationHelper defaultManager].keepLocation = NO;
        [[PHLocationHelper defaultManager].locationManager startUpdatingLocation];
    }
    else {
        PH_ShowTips(@"为了更好的体验App，请打开定位功能");
    }
}

/**
 开始定位
 */
+ (void)ph_startLocation {
    [PHLocationHelper defaultManager].keepLocation = YES;
    [[PHLocationHelper defaultManager].locationManager startUpdatingLocation];
}

/**
 停止定位
 */
+ (void)ph_stopLocation {
    [PHLocationHelper defaultManager].keepLocation = NO;
    [[PHLocationHelper defaultManager].locationManager stopUpdatingLocation];
}

#pragma mark -- address delegate

#pragma mark -- location delegate
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation {
    PHBaseVC *vc = (PHBaseVC *)PH_CurrentVC();
    if ([vc respondsToSelector:@selector(ph_location:oldLocation:)]) {
        [vc ph_location:newLocation oldLocation:oldLocation];
    }

    /*
     子类实现了address 协议才去反向地址方法
     */
    if ([vc respondsToSelector:@selector(ph_address:info:)]) {
        [self.geocoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            if (error == nil) {
                CLPlacemark *place = [placemarks firstObject];
                [self.address deleteCharactersInRange:NSMakeRange(0, self.address.length)];
                [self.address appendString:place.country];
                [self.address appendString:place.subAdministrativeArea];
                [self.address appendString:place.administrativeArea];
                [self.address appendString:place.subLocality];
                [self.address appendString:place.locality];
                [self.address appendString:place.subThoroughfare];
                [self.address appendString:place.thoroughfare];
                [self.address appendString:place.name];
                PHBaseVC *vc = (PHBaseVC *)PH_CurrentVC();
                if ([vc respondsToSelector:@selector(ph_address:info:)]) {
                    [vc ph_address:self.address info:place];
                }
            }
            else {
                PHLogError(@"%@", error);
            }
        }];
    }
    
    if (!self.keepLocation) {//定位成功以后立即关闭定位
        [PHLocationHelper ph_stopLocation];
    }
}

- (void)locationManager:(CLLocationManager *)manager
       didUpdateHeading:(CLHeading *)newHeading {
}

@end
