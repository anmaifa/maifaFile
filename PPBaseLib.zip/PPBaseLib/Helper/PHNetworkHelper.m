//
//  PHNetworkHelper.m
//  App
//
//  Created by 安武 on 2017/6/18.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHNetworkHelper.h"
#import "PHBaseVC.h"
#import "PHTools.h"

@implementation PHNetworkHelper

PH_DefaultManager(PHNetworkHelper);

+ (void)ph_monitorNetworkStatus {
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        [PHNetworkHelper defaultManager].status = status;
        PHBaseVC *vc = (PHBaseVC *)PH_CurrentVC();
        if ([vc respondsToSelector:@selector(ph_networkStatus:)]) {
            [vc ph_networkStatus:status];
        }
    }];
}

@end
