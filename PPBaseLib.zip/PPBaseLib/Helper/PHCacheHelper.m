//
//  PHCacheHelper.m
//  App
//
//  Created by Alex on 2017/6/19.
//  Copyright © 2017年 安武. All rights reserved.
//

#import "PHCacheHelper.h"

@implementation PHCacheHelper

PH_DefaultManager(PHCacheHelper);

@end
