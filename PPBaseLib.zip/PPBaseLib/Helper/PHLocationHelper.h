//
//  PHLocationHelper.h
//  App
//
//  Created by 安武 on 2017/6/18.
//  Copyright © 2017年 安武. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "PHTools.h"
#import "PHMacro.h"

@interface PHLocationHelper : NSObject<CLLocationManagerDelegate>

PH_DefaultManagerHeader(PHLocationHelper);

/**
 初始化定位设置 定位成功以后立即关闭定位
 */
+ (void)ph_locationManager;
/**
 开始定位
 */
+ (void)ph_startLocation;

/**
 停止定位
 */
+ (void)ph_stopLocation;

@end
