//
//  PHLogHelper.h
//  App
//
//  Created by 安武 on 2017/6/19.
//  Copyright © 2017年 安武. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PHMacro.h"

@interface PHLogHelper : NSObject

PH_DefaultManagerHeader(PHLogHelper);

/**
 开启日志管理系统
 */
+ (void)ph_startLogManager;

/**
 关闭日志管理系统
 */
+ (void)ph_stopLogManager;

@end
