//
//  PHNetworkProtocol.h
//  App
//
//  Created by 安武 on 2017/6/18.
//  Copyright © 2017年 安武. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking.h>

@protocol PHNetworkProtocol <NSObject>

@optional
/**
 网络状态的变化
 
 @param status 网络状态
 */
- (void)ph_networkStatus:(AFNetworkReachabilityStatus)status;

@end
