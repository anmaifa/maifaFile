//
//  ViewController.h
//  NewPagedFlowViewDemo
//
//  Copyright © 2016年 Mars. All rights reserved.
//  Designed By PageGuo,
//  QQ:799573715
//  github:https://github.com/PageGuo/NewPagedFlowView

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

