//
//  ViewController.h
//  BluetoothPrint
//
//  Created by tuzhengyao 16/3/27.
//  Copyright © 2016年 Tgs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property(nonatomic,strong)NSTimer *reloadTimer;
@property(nonatomic,assign)NSInteger printNum;
@end

