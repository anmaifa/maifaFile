//
//  ZYBTPrinterTool.h
//  JuniuHD
//
//  Created by ZYSu on 2016/12/6.
//  Copyright © 2016年 ZYSu. All rights reserved.
//  蓝牙4.0通用

#import <Foundation/Foundation.h>
#import "ZYPrinterProtocol.h"

@interface ZYBTPrinterTool : NSObject<ZYPrinterProtocol>

@end
