//
//  ZYMFIPrinterTool.h
//  JuniuHD
//
//  Created by ZYSu on 2016/12/6.
//  Copyright © 2016年 ZYSu. All rights reserved.
//  毕索龙打印机专用 MFI认证

#import <Foundation/Foundation.h>
#import "ZYPrinterProtocol.h"

@interface ZYMFIPrinterTool : NSObject<ZYPrinterProtocol>

@end
