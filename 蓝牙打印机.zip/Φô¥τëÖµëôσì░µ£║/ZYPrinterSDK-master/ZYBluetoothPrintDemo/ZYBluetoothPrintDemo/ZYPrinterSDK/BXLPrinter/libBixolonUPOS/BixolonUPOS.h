//
//  BixolonUPOS.h
//  BixolonUPOS
//
//  Created by savin on 13. 11. 1..
//  Copyright (c) 2013년 savin. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "oposinc/Opos.h"
@interface BixolonUPOS : NSObject

-(void) testFunction : (NSString*) strTest;

@end
