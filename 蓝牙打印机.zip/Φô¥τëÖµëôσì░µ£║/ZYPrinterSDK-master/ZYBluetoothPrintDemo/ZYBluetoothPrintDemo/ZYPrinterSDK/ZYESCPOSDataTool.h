//
//  ZYESCPOSDataTool.h
//  ZYBluetoothPrintDemo
//
//  Created by ZYSu on 2017/4/17.
//  Copyright © 2017年 ZYSu. All rights reserved.
//  EPSON 标准蓝牙打印指令

#import <Foundation/Foundation.h>
#import "ZYPrinterDataProtocol.h"

@interface ZYESCPOSDataTool : NSObject<ZYPrinterDataProtocol>

@end
