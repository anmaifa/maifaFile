//
//  UPOSPrinterController+zy.h
//  Juniu
//
//  Created by ZYSu on 2016/10/13.
//  Copyright © 2016年 com.juniu. All rights reserved.
//

#import "UPOSPrinterController.h"

@interface UPOSPrinterController (ZY)

+ (instancetype)sharedInstance;

@end
